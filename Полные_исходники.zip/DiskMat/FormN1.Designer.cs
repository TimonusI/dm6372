﻿namespace DiskMat
{
    partial class FormN1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inputBox1 = new DiskMat.InputBox();
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.inputBox2 = new DiskMat.InputBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // inputBox1
            // 
            this.inputBox1.Location = new System.Drawing.Point(15, 12);
            this.inputBox1.Name = "inputBox1";
            this.inputBox1.Size = new System.Drawing.Size(119, 20);
            this.inputBox1.TabIndex = 0;
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.AutoSize = true;
            this.ErrorLabel.Location = new System.Drawing.Point(3, 46);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(35, 13);
            this.ErrorLabel.TabIndex = 1;
            this.ErrorLabel.Text = "label1";
            // 
            // inputBox2
            // 
            this.inputBox2.Location = new System.Drawing.Point(165, 12);
            this.inputBox2.Name = "inputBox2";
            this.inputBox2.Size = new System.Drawing.Size(119, 20);
            this.inputBox2.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label1.Location = new System.Drawing.Point(140, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "=";
            // 
            // FormN1
            // 
            this.ClientSize = new System.Drawing.Size(298, 70);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.inputBox2);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.inputBox1);
            this.Name = "FormN1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private InputBox inputBox1;
        private System.Windows.Forms.Label ErrorLabel;
        private InputBox inputBox2;
        private System.Windows.Forms.Label label1;
    }
}
