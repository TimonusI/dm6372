﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormQ4 : DiskMat.Module
    {

        public FormQ4()
        {
            Text = "Q_4";
            InitializeComponent();
        }

        public override void ErrorHandle()
        {
            label1.Text = "= ?";
        }
        public override void Run()
        {
            label1.Text = "= " + Q_4.Run(rationalBox1.Value).ToString();
        }

        public override void Resize()
        {
            this.Width = 25 + label1.Left + label1.Width;
        }

        public override void SpecialConditionHandle()
        {
            ErrorBorder(rationalBox1.NumBox);
            //ErrorBorder(rationalBox1.DenomBox);
            ErrorLabel.Text = "Несократимая дробь";
            ErrorHandle();
            Resize();
        }
    }
}
