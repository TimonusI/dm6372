﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormQ1 : DiskMat.Module
    {
        public FormQ1()
        {
            Text = "Q_1";
            InitializeComponent();
        }

        public override void ErrorHandle()
        {
            rationalLabel1.Unknown();
        }
        public override void Run()
        {
            rationalLabel1.Value = Q_1.Run(rationalBox1.Value);
        }

        public override void Resize()
        {
            this.Width = 25 + rationalLabel1.Left + rationalLabel1.Width;
        }
    }
}
