﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormN2 : DiskMat.Module
    {
        public FormN2()
        {
            Text = "N_2";
            InitializeComponent();
        }


        public override void ErrorHandle()
        {
            label1.Text = "?";
        }
        public override void Run()
        {
            label1.Text = N_2.Run(new Natural(inputBox1.Text)) ? "=" : "!=";
        }
    }
}
