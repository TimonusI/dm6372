﻿namespace DiskMat
{
    partial class FormQ3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inputBox1 = new DiskMat.DigitBox();
            this.rationalLabel1 = new DiskMat.RationalLabel();
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // inputBox1
            // 
            this.inputBox1.Location = new System.Drawing.Point(12, 12);
            this.inputBox1.Name = "inputBox1";
            this.inputBox1.Size = new System.Drawing.Size(117, 20);
            this.inputBox1.TabIndex = 12;
            // 
            // rationalLabel1
            // 
            this.rationalLabel1.Location = new System.Drawing.Point(156, 2);
            this.rationalLabel1.Name = "rationalLabel1";
            this.rationalLabel1.Size = new System.Drawing.Size(19, 38);
            this.rationalLabel1.TabIndex = 26;
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.AutoSize = true;
            this.ErrorLabel.Location = new System.Drawing.Point(-1, 35);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(35, 13);
            this.ErrorLabel.TabIndex = 25;
            this.ErrorLabel.Text = "label1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label1.Location = new System.Drawing.Point(134, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 17);
            this.label1.TabIndex = 24;
            this.label1.Text = "=";
            // 
            // FormQ3
            // 
            this.ClientSize = new System.Drawing.Size(180, 49);
            this.Controls.Add(this.rationalLabel1);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.inputBox1);
            this.Name = "FormQ3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DigitBox inputBox1;
        private RationalLabel rationalLabel1;
        private System.Windows.Forms.Label ErrorLabel;
        private System.Windows.Forms.Label label1;
    }
}
