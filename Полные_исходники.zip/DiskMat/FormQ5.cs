﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormQ5 : DiskMat.Module
    {

        public FormQ5()
        {
            Text = "Q_5";
            InitializeComponent();
        }

        public override void ErrorHandle()
        {
            rationalLabel1.Unknown();
        }
        public override void Run()
        {
            rationalLabel1.Value = Q_5.Run(rationalBox1.Value, rationalBox2.Value);
        }

        public override void Resize()
        {
            this.Width = 25 + rationalLabel1.Left + rationalLabel1.Width;
        }

    }
}
