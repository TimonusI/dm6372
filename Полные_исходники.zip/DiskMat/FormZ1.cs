﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormZ1 : DiskMat.Module
    {
        public FormZ1()
        {
            Text = "Z_1";
            
            InitializeComponent();
            this.Width = label2.Location.X + label2.Width + 25;
        }

        public override void ErrorHandle()
        {
            label2.Text = "| = ?";
        }
        public override void Run()
        {
            label2.Text = "| = "+Z_1.Run(inputBox2.Value).ToString();
            this.Width = label2.Location.X + label2.Width + 25;
        }
    }
}
