﻿namespace DiskMat
{
    partial class RationalLabel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Num = new System.Windows.Forms.Label();
            this.Denom = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Num
            // 
            this.Num.AutoSize = true;
            this.Num.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.Num.Location = new System.Drawing.Point(3, 0);
            this.Num.Name = "Num";
            this.Num.Size = new System.Drawing.Size(16, 17);
            this.Num.TabIndex = 0;
            this.Num.Text = "?";
            // 
            // Denom
            // 
            this.Denom.AutoSize = true;
            this.Denom.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.Denom.Location = new System.Drawing.Point(3, 21);
            this.Denom.Name = "Denom";
            this.Denom.Size = new System.Drawing.Size(16, 17);
            this.Denom.TabIndex = 1;
            this.Denom.Text = "?";
            // 
            // RationalLabel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.Denom);
            this.Controls.Add(this.Num);
            this.Name = "RationalLabel";
            this.Size = new System.Drawing.Size(22, 42);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.RationalLabel_Paint);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Num;
        private System.Windows.Forms.Label Denom;
    }
}
