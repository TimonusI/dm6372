﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiskMat
{
    
    public partial class FormMenu : Form
    {
        public FormMenu()
        {
            InitializeComponent();
            List<ButtonClick> buttons = new List<ButtonClick>();
            buttons.Add(new ButtonClick("Сравнение",                                    typeof(FormN1),  ButtonClick.Fields.Natural));
            buttons.Add(new ButtonClick("Равенство нулю",typeof(FormN2),  ButtonClick.Fields.Natural));
            buttons.Add(new ButtonClick("Прибавление единицы",typeof(FormN3),  ButtonClick.Fields.Natural));
            buttons.Add(new ButtonClick("Сложение",typeof(FormN4),  ButtonClick.Fields.Natural));
            buttons.Add(new ButtonClick("Вычитание",                                    typeof(FormN5),  ButtonClick.Fields.Natural));
            buttons.Add(new ButtonClick("Умножение на короткое число",                  typeof(FormN6),  ButtonClick.Fields.Natural));
            buttons.Add(new ButtonClick("Умножение на k^10",                            typeof(FormN7),  ButtonClick.Fields.Natural));
            buttons.Add(new ButtonClick("Умножение",                                    typeof(FormN8),  ButtonClick.Fields.Natural));
            buttons.Add(new ButtonClick("Вычитание по модулю (с умножением на цифру)",  typeof(FormN9), ButtonClick.Fields.Natural));
            buttons.Add(new ButtonClick("Вычисление первой цифры деления и умножение ее на 10^k, где k - ее разряд", typeof(FormN1_0), ButtonClick.Fields.Natural));
            buttons.Add(new ButtonClick("Частное от деления",                           typeof(FormN11), ButtonClick.Fields.Natural));
            buttons.Add(new ButtonClick("Остаток от деления",                           typeof(FormN12), ButtonClick.Fields.Natural));
            buttons.Add(new ButtonClick("НОД",                                          typeof(FormN13), ButtonClick.Fields.Natural));
            buttons.Add(new ButtonClick("НОК",                                          typeof(FormN14), ButtonClick.Fields.Natural));
            buttons.Add(new ButtonClick("Модуль", typeof(FormZ1), ButtonClick.Fields.Digit));
            buttons.Add(new ButtonClick("Знак", typeof(FormZ2), ButtonClick.Fields.Digit));
            buttons.Add(new ButtonClick("Умножение на -1", typeof(FormZ3), ButtonClick.Fields.Digit));
            buttons.Add(new ButtonClick("Преобразование натурального в целое", typeof(FormZ4), ButtonClick.Fields.Digit));
            buttons.Add(new ButtonClick("Преобразование неотрицательного целого в натуральное", typeof(FormZ5), ButtonClick.Fields.Digit));
            buttons.Add(new ButtonClick("Сложение", typeof(FormZ6), ButtonClick.Fields.Digit));
            buttons.Add(new ButtonClick("Вычитание", typeof(FormZ7), ButtonClick.Fields.Digit));
            buttons.Add(new ButtonClick("Умножение", typeof(FormZ8), ButtonClick.Fields.Digit));
            buttons.Add(new ButtonClick("Частное от деления", typeof(FormZ9), ButtonClick.Fields.Digit));
            buttons.Add(new ButtonClick("Остаток от деления", typeof(FormZ10), ButtonClick.Fields.Digit));
            buttons.Add(new ButtonClick("Сокращение дроби", typeof(FormQ1), ButtonClick.Fields.Rational));
            buttons.Add(new ButtonClick("Проверка на целое", typeof(FormQ2), ButtonClick.Fields.Rational));
            buttons.Add(new ButtonClick("Преобразование целого в дробь", typeof(FormQ3), ButtonClick.Fields.Rational));
            buttons.Add(new ButtonClick("Преобразование дроби в целое (если возможно)", typeof(FormQ4), ButtonClick.Fields.Rational));
            buttons.Add(new ButtonClick("Сложение", typeof(FormQ5), ButtonClick.Fields.Rational));
            buttons.Add(new ButtonClick("Вычитание", typeof(FormQ6), ButtonClick.Fields.Rational));
            buttons.Add(new ButtonClick("Умножение", typeof(FormQ7), ButtonClick.Fields.Rational));
            buttons.Add(new ButtonClick("Деление", typeof(FormQ8), ButtonClick.Fields.Rational));

            foreach (ButtonClick BC in buttons)
            {
                Button B = GenButton(BC.text, BC.T);
                GroupBox g = getGroup(BC.Field);
                g.Controls.Add(B);
                B.Location = new Point(0, g.Height);
                g.Height = B.Height + B.Location.Y;
            }
            groupBox4.Top = groupBox1.Top + groupBox1.Height + 10;
           // groupBox4.Top = groupBox2.Top + groupBox2.Height + 10;
            groupBox3.Top = groupBox2.Top + groupBox2.Height + 10;
        }

        GroupBox getGroup(ButtonClick.Fields F)
        {
            switch (F)
            {
                case ButtonClick.Fields.Digit: return groupBox2;
                case ButtonClick.Fields.Rational: return groupBox4;
                default: return groupBox1;
            }
        }

        void NextForm(Form F)
        {
            this.Hide();
            F.ShowDialog();
            this.Show();
        }

        Button GenButton(string text, Type T)
        {
            Button B = new Button();
            B.Text = text;
            B.Width = 304;
            B.Height = 56;
            B.Margin = new Padding(0);
            //var type = typeof(Form).MakeGenericType(T.GetType());
            B.Click += delegate { NextForm(Activator.CreateInstance(T) as Form); };
            return B;
        }
        
    }

    public class ButtonClick
    {
        public enum Fields { Natural, Digit, Rational, Polymoninal }

        public string text;
        public Type T;
        public Fields Field;

        public ButtonClick(string s, Type t, Fields F)
        {
            T = t;
            text = s;
            Field = F;
        }
    }
}
