﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DiskMat
{
    public partial class FormN13 : DiskMat.Module
    {
        public FormN13()
        {
            Text = "N_13";
            InitializeComponent();
        }
        public override void ErrorHandle()
        {
            label2.Text = ") = ?";
        }

        public override void Run()
        {
            label2.Text = ") = " + N_13.Run(inputBox1.Value, inputBox2.Value);
            this.Width = label2.Location.X + label2.Width + 25;
        }

    }
}
