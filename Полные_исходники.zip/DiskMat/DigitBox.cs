﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace DiskMat
{
    public class DigitBox : InputBox
    {
        public override Regex Formula()
        {
            return new Regex(@"^(\+|\-){1}\d+$|^\d*$");
        }

        public Digit Value
        {
            get { return new Digit(!Text.Contains("-"), Text.Replace("-","").Replace("+","")); }
        }
    }
}
